﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for global
/// </summary>
public class global
{
	public global()
	{
		//
		// TODO: Add constructor logic here
		//

	}
}